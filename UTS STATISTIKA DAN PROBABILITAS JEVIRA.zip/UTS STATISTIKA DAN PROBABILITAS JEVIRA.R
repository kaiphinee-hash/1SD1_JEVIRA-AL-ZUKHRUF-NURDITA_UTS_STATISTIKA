# Membuat data penjualan Toko A

data_penjualan <- data.frame(
  Tahun = 2010:2020,
  Gula = c(50, 70, 100, 120, 110, 100, 120, 135, 140, 150, 145),
  Minyak = c(80, 85, 90, 100, 120, 125, 135, 140, 150, 190, 195),
  Sabun = c(55, 70, 80, 95, 80, 100, 105, 110, 120, 100, 130)
)


print(data_penjualan)

summary(data_penjualan)

par(mfrow = c(2, 2), mar = c(4, 4, 3, 1))

plot(data_penjualan$Tahun, data_penjualan$Gula,
     type = "o",
     col = "red",
     main = "Grafik Penjualan Gula",
     xlab = "Tahun",
     ylab = "Jumlah Penjualan")

plot(data_penjualan$Tahun, data_penjualan$Minyak,
     type = "o",
     col = "blue",
     main = "Grafik Penjualan Minyak",
     xlab = "Tahun",
     ylab = "Jumlah Penjualan")

plot(data_penjualan$Tahun, data_penjualan$Sabun,
     type = "o",
     col = "green",
     main = "Grafik Penjualan Sabun",
     xlab = "Tahun",
     ylab = "Jumlah Penjualan")

matplot(data_penjualan$Tahun,
        data_penjualan[, c("Gula", "Minyak", "Sabun")],
        type = "o",
        col = c("red", "blue", "green"),
        pch = 16,
        lty = 1,
        main = "Grafik Penjualan Gula, Minyak, dan Sabun",
        xlab = "Tahun",
        ylab = "Jumlah Penjualan")

legend("topleft",
       legend = c("Gula", "Minyak", "Sabun"),
       col = c("red", "blue", "green"),
       lty = 1,
       pch = 16)

par(mfrow = c(1, 1))